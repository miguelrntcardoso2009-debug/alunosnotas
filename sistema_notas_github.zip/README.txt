SISTEMA DE NOTAS - VERSÃO GITHUB PAGES

Esta versão funciona em hospedagem estática, como GitHub Pages.

Arquivos:
- index.html
- style.css
- script.js

LOGIN DO PROFESSOR:
Usuário: professor
Senha: 123456

O professor pode cadastrar alunos, senhas e notas.
O aluno pode entrar e visualizar somente sua própria nota.

IMPORTANTE:
Como o GitHub Pages não executa PHP nem possui banco MySQL, esta versão utiliza:
- localStorage para salvar alunos e notas;
- sessionStorage para simular a sessão;
- JavaScript para controlar login e permissões.

Portanto, é uma versão funcional para demonstração no GitHub Pages, mas NÃO substitui um banco SQL/PHP real.
